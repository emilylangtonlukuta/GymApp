
public class Member {
	private int memberID;
	private String memberName;
	private String memberAddress;
	private double Height;
	private double startingWeight;
	private String Gender;
	double bmi = 0.00;
	
	  public Member(int numberIn, String name,String name2,double double1,double double2,String name3)
	  {
		  memberID=numberIn;
		  memberName=name;
		  memberAddress= name2;
		  Height=double1;
		  startingWeight=double2;
		  Gender=name3;
	  }


	public int getmemberID()
	    {
	        return memberID;
	    }
	  
	  public String getmemberName()
	    {
	        return memberName;
	    }
	  
	  public String getmemberAddress()
	    {
	        return memberAddress;
	    }
	  
	  public double getHeight()
	    {
	        return Height;
	    }
	
	  public double getstartingWeight()
	    {
	        return startingWeight;
	    }
	  
	  public String getGender()
	  {
		  return Gender;
	  }
	  
	  
// setter methods to assign new values individually to the attributes
	  
	  public void setmemberID(int memberID)
	  {
		  this.memberID = memberID;
	  }
	 
	  public void setmemberName(String memberName)
	   {
	       this.memberName= memberName;
	   }
	  
	  public void setmemberAddress(String memberAddress)
	   {
	       this.memberAddress= memberAddress;
	   }
	  
	  public void setHeight(double Height)
	   {
	       this.Height= Height;
	   }
	  
	  public void setstartingWeightt(double startingWeight)
	   {
	       this.startingWeight= startingWeight;
	   }
	  
	  public void setGender(String Gender)
	   {
	       this.Gender= Gender;
	   }

	  
	  
	  
	  
	  
	    private double toTwoDecimalPlaces(double num){
	        return (int) (num *100 ) /100.0; 
	    }

	    //When returning the result of a calculation, we want to call our 
	    //new toTwoDecimalPlaces method to truncate the result to two decimal places:
	//    public double calculateSomething(int value){
//	        return toTwoDecimalPlaces(  value / anotherValue );
//	    }	
	    
	    
   public boolean isIdealbodyWeight() {
	   if(startingWeight > Height )
       {
      return true ;
	        }	
      else
	        {
            return false;}
	        }
	   
	   
	           
	            
	            public double calculateSomething(){
	                return toTwoDecimalPlaces(  Height/ startingWeight );
	            }
        	
	        	
public double calculateBMI() {

  return bmi = (startingWeight/Math.sqrt(Height));


}

public String determineBMICategory()
{   
    double bmi = calculateBMI();

    if (bmi < 15)
    {
        return "VERY SEVERELY UNDERWEIGHT";
    }

    else if (bmi >= 15 && bmi < 16)
    {
        return "SEVERELY UNDERWEIGHT";
    }

    else if (bmi >= 16 && bmi < 18.5)
    {
        return "UNDERWEIGHT";
    }

    else if (bmi >= 18.5 && bmi < 25)
    {
        return "NORMAL";
    }

    else if (bmi >= 25 && bmi < 30)
    {
        return "OVERWEIGHT";
    }

    else if (bmi >= 30 && bmi < 35)
    {
        return "MODERATELY OBESE";
    }

    else if (bmi >= 35 && bmi < 40)
    {
        return "SEVERELY OBESE";
    }

    else
    {
        return "VERY SEVERELY OBESE";
    }
}


public double	listMembershipDetailsImperialAndMetric() {

return startingWeight;
}
	  public String toString()
	    {
	    	return " Member id: " + memberID + " Name:  " + memberName + " Address: " + memberAddress+ " Height:  " + Height+ " Starting Weight:  " + startingWeight+ " Gender:  " + Gender;
	    }
	  }
	 

