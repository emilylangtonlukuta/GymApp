import java.util.Scanner;

public class MenuController {

	private Scanner input;
    private Gym gym;
    
    public static void main (String args[]){
    	MenuController gym = new MenuController();
    }
    
    public MenuController()
    {
    	input = new Scanner(System.in);    

        //read in the details....
        System.out.println("Please enter the Gym...");
        System.out.print("\tName: ");
        String gymName = input.nextLine();
        System.out.print("\tManager Name: ");
        String managerName = input.nextLine();
        System.out.print("\tPhone Number: ");
        String phoneNumber = input.nextLine();

        gym = new Gym(gymName,managerName,phoneNumber);
        runMenu();
    }

    private int mainMenu()
    { 
    	System.out.println("*** GYM MENU***");
        System.out.println("---------");     
        System.out.println("  1) Add a member");    
        System.out.println("  2) List all members");
        System.out.println("  3) Remove a member(by index)");
        System.out.println("  4) Number of members in the gym");
        System.out.println("---------"); 
        System.out.println("  5) List gym details");       
        System.out.println("  6) List members with ideal starting weight");        
        System.out.println("  7) List members with a specific BMI category");   
        System.out.println("  8) List all members stats imperically and metrically");
        System.out.println("  9) Save Member to Member.xml");
        System.out.println("  10) Load Member from Member.xml");
        System.out.println("  0) Exit");
        System.out.print("==>> ");
        int option = input.nextInt();
        return option;
    }

    private void runMenu()
    {
        int option = mainMenu();
        while (option != 0)
        {

            switch (option)
            {
           case 1:     addMembership();
					   break;
           case 2:     System.out.println(gym.listMember());
			           break;
           case 3:     deleteMember();
                       break;
           case 4:     System.out.println("Number of members: " + gym.numberOfMember());
			           break;   
           case 6:     System.out.println(gym.listMembershipstartingWeight());
                       break;
           case 7:     System.out.println(gym.listBySpecificBMICategory());
                       break;
           case 8 :    listMembershipDetailsImperialAndMetric();
                       break;
           case 9: 	try{
				gym.save();
			}
			catch(Exception e){
				System.out.println("Error writing to file:  " + e);
			}
			break;
case 10:	try{
				gym.load();
			}
			catch(Exception e)
			{
				System.out.println("Error reading from file: " + e);
			}
			break;
            default:   	System.out.println("Invalid option entered: " + option);
                        break;
            }
       
        
            //pause the program so that the user can read what we just printed to the terminal window
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();  //this second read is required - bug in Scanner class; a String read is ignored straight after reading an int.

            //display the main menu again
            option = mainMenu();
        }

        //the user chose option 0, so exit the program
        System.out.println("Exiting... bye");
        System.exit(0);
        
        
        }

   

	private String listMembershipDetailsImperialAndMetric() {
		return  gym.listMember();
		
	}


	private void addMembership()
    {
	System.out.println("Please enter the following account details");
    int memberID = input.nextInt();
    System.out.print("Enter ID:  ");
    String memberName = input.nextLine();
    System.out.print("Enter the Unit Cost:  ");
    String memberAddress = input.nextLine();
    System.out.print("Enter :  ");
    double Height = input.nextDouble();
    System.out.print("Enter the Unit Cost:  ");
    double startingWeight = input.nextDouble();
    System.out.print("Enter the Unit Cost:  ");
    String Gender = input.nextLine();
    System.out.print("Enter the Unit Cost:  ");
    
        gym.add(new Member(memberID,memberName,memberAddress,Height,startingWeight,Gender));
    }


    private void deleteMember()
    {
        //list the products and ask the user to choose the account to edit
        System.out.println(gym.listMember());

        if (gym.numberOfMember() != 0){   
            //only process the delete if account exist in the ArrayList
            System.out.print("Index of account to delete ==>");
            int index = input.nextInt();

            if (index < gym.numberOfMember() ){    
                //if the index number exists in the ArrayList, delete it from the ArrayList
                gym.remove(index);
                System.out.println("Account deleted.");
            }
            else
            {
                System.out.println("There is no account for this index number");
            }
        }
    }
    
}


   
