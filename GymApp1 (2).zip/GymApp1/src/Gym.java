import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
/**
 * Gym class 
 * @author Emily Lukuta (w20079889)
 */


public class Gym {
	
	 // attributes
	private String gymName;
	private String managerName;
	private String phoneNumber;
	
	
	private ArrayList<Member> App; // to hold the accounts

	   public Gym(String phoneNumber)
	    {
		   this.phoneNumber = phoneNumber; 
	        //initialise phone number to value entered
	        for (int i = 0; i < phoneNumber.length(); i++)
	        {   //then check phone number is digits only   
	            if (!Character.isDigit(phoneNumber.charAt(i)))
	            {   //searches string for a non-digit   
	                this.phoneNumber = "unknown";
	            }   //updates if a digit is found
	        }
	        
	    	App = new ArrayList<Member>();
	           
	    }

public Gym(String gymName, String managerName,String phoneNumber2 ){
    setgymName(gymName);
    setmanagerName(managerName);
  
    App = new ArrayList<>();
}



	


public ArrayList<Member> getMembership()
{
	return App;
}

//Getters

public String getgymName()
  {
      return gymName;
  }

public String getmanagerName()
  {
      return managerName;
  }

public String getphoneNumber()
  {
      return phoneNumber;
  }

//setters

public void setgymName(String gymName)
{
	  this.gymName = gymName;
}

public void setmanagerName(String managerName)
 {
     this.managerName= managerName;
 }
public void setPhoneNumber(String phoneNumber)
{  
for (int i = 0; i < phoneNumber.length(); i++) 
{   //check phone number is digits only
    if (!Character.isDigit(phoneNumber.charAt(i)))
    {   //searches string for a non-digit
        phoneNumber = this.phoneNumber;
    }   //return back to original number if a non-digit is found
}
this.phoneNumber = phoneNumber;
}

//methods

	public void add (Member member){
      App.add (member); 
  }

	
	
	public void remove(int index){
        App.remove(index);
    }
	

     public int numberOfMember(){
         return App.size();
     }

     public String listMember(){
         if (App.size() > 0){
        	 
             String listOfMember = "";
             for (int i = 0; i < numberOfMember(); i++){
                 listOfMember += i + ": " + App.get(i) + "\n";        
             }
             return listOfMember;
         }
         else{
             return "There are no members in the gym";
         }
     } 
  public String listBySpecificBMICategory(String category) {
	  
	
	  String list = "";
      category = category.toUpperCase();
      for (int index = 0; index < App.size(); index++)
      {
          if (App.get(index).determineBMICategory().contains(category))
          {
              list = list + App.get(index).getmemberName() + "\n";
          }
      }
      if (list.equals(""))
      {
          return "There are no members in this category";
      }
      else
      {
          return list;
      }
  }               
	  
	  
	  
	  
	  
	  

	public String listMembershipstartingWeight()
	{
		String str = "";    
		for (int i = 0; i < App.size(); i++){
			if (App.get(i).getstartingWeight() >=0)
				str = str + i + ": " + App.get(i) + "\n";
		}
		
		if (str.equals(""))
			return "No accounts with starting weight!";
		else
			return str;	
	}    



public String toString(){
    return ("Gym name:" + gymName
    		+ "Manager Name: " + managerName 
           + "Phone Number: " + phoneNumber
            + listMember());

}















@SuppressWarnings("unchecked")
public void load() throws Exception
{
    XStream xstream = new XStream(new DomDriver());
    ObjectInputStream is = xstream.createObjectInputStream(new FileReader("Member.xml"));
   App = (ArrayList<Member>) is.readObject();
    is.close();
}

public void save() throws Exception
{
    XStream xstream = new XStream(new DomDriver());
    ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("Member.xml"));
    out.writeObject(App);
    out.close();    
}




}






